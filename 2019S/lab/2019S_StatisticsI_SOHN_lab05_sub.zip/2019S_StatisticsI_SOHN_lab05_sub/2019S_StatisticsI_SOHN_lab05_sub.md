
<style>
.midcenter {
    position: fixed;
    top: 50%;
    left: 50%;
}


.footer {
    color: black; background: #E8E8E8;
    position: fixed; top: 90%;
    text-align:center; width:100%;
}


.small-code pre code {
  font-size: 1.2em;
}

.reveal h1, .reveal h2, .reveal h3 {
  word-wrap: normal;
  -moz-hyphens: none;
}

</style>



Statistics I Lab 05
========================================================
author: Yunkyu Sohn  
date: Addendum (not on exams)
width: 1000
height: 700
transition: none

## dplyr package
<img src="Images/pse.png" height=30% width=30% style="background-color:transparent; border:0px; box-shadow:none;"></img>

Modified from https://compass-workshops.github.io/info/
[//]: # (This work is licensed under a <a rel="license" href="http://creativecommons.org/licenses/by/3.0/deed.en_US">Creative Commons Attribution 3.0 Unported License</a>.)

Addendum
========================================================
type: section

1. Programming with dplyr
2. Aggregating with dplyr

Addendum 1: Programming with dplyr
========================================================
type: section

Mission for Addendum #1: Which Countries are Happiest?
========================================================
type: prompt

- Which countries are the happiest?
- To answer this question, we'll use the dplyr package

Subsetting Both Observations and Variables
========================================================
class: small-code

- Install the `dplyr` package
- Try this R code:

```
filter(World, Happiness > 5)
filter(World, Happiness > 7)
select(World, Happiness, Region)
```

Selecting both rows and columns with nesting
========================================================

- Install the `dplyr` package

- Try this R code:
```
filter(select(World, Happiness, Region), Happiness > 5)
```

Introducing the %>% Operator
========================================================
class: small-code

- Can be interpreted as "then"
- Try this R code:

```
World %>% select(HDI, Happiness, Region) %>% filter(Happiness > 5)
```
Helper Functions for select()
========================================================
class: small-code

-	`contains()`: select columns containing a character string: 
- `select(World, contains("United"))`

- `starts_with()`: select columns with names starting in a character string: 
- `select(World, starts_with("Reg"))`

- `ends_with()`: select columns with names ending in a character string: 
- `select(World, ends_with("DI"))`


Challenge for Addendum #1: Happy Countries
========================================================
type: prompt
incremental: true

- Which countries are happiest among those countries with a population above 20 million? How about those below 20 million?

- **R Code** Hint:

```
World %>% select(HDI, Population, Country, Happiness, Region) %>% filter(Happiness > 5 & Population < 20)

```
- Is this finding surprising to you?

Check-In for Addendum #1: Programming with dplyr
========================================================
type: alert

- At this point you should have:
 - Learned about subsetting with filter and select
 - Examined how this compares with conventional subsettting techniques


Addendum #2: Aggregating with dplyr
========================================================
type: section

Mission for Addendum #2: Life Expectancy by Region
========================================================
type: prompt

- What is the average life expectancy by region?
- We will use real data again!

Aggregating Data with Base R
========================================================

- Recall this R Code

```
tapply(X=World$Happiness, INDEX=World$Region, FUN=mean)
```

Using dplyr
=======================================================

- Now with dplyr!
- Try this R Code

```
World %>%  group_by(Region) %>% summarise(MeanHDI = mean(HDI))
```
Challenge for Addendum #2: Life Expectancy by Region
========================================================
type: prompt
incremental: true

- What is the life expectancy by region?

- **R Code** Hint:

```
World %>%  group_by(Region) %>% summarise(MeanLife = mean(LifeExpectancy))

```
- Is this finding surprising to you?


Recap of the Workshop
========================================================
type: section

- At this point you should have:
 - Created for loops
 - Constructed conditional statements
 - Learned about the apply family of functions
